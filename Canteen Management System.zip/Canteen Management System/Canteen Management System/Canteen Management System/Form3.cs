﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Canteen_Management_System
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        public void display()
        {
            SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-3NOASSJ;Initial Catalog=CANTEEN MANAGEMENT SYSTEM.MDF;Integrated Security=True");
            sqlConnection.Open();
            SqlCommand cmd = sqlConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from [Order Details]";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;


            sqlConnection.Close();
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            display();
        }
    }
}
